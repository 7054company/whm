<?php
/*
 * @ https://EasyToYou.eu - IonCube v10 Decoder Online
 * @ PHP 5.6
 * @ Decoder version: 1.0.4
 * @ Release: 02/06/2020
 *
 * @ ZendGuard Decoder PHP 5.6
 */

echo "<h3>Disconnect</h3>\n\n<p>Are you sure you wish to disconnect WHMCS from your Mailchimp account?</p>\n\n<p>This will stop syncing of any new data.<br>It will not affect any existing mailing list subscriptions.</p>\n\n<br>\n\n<p>\n    <button type=\"submit\" class=\"btn btn-danger\">\n        Confirm and Disconnect\n    </button>\n</p>\n\n<input type=\"hidden\" name=\"action\" value=\"disconnectconfirm\">\n";

?>