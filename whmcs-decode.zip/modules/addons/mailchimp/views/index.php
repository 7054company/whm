<?php
/*
 * @ https://EasyToYou.eu - IonCube v10 Decoder Online
 * @ PHP 5.6
 * @ Decoder version: 1.0.4
 * @ Release: 02/06/2020
 *
 * @ ZendGuard Decoder PHP 5.6
 */

echo "<p>Connected to MailChimp Account: <strong>";
echo $accountUsername;
echo "</strong></p>\n\n<br>\n\n<p>Sync Status: <span class=\"label label-success\" style=\"margin-left:8px;padding:5px 10px;font-size:1em;text-transform:initial;\">All up-to-date</span></p>\n\n<br>\n\n<p>To setup automations or start a new campaign, visit <a href=\"https://login.mailchimp.com/\" target=\"_blank\">www.mailchimp.com</a></p>\n";

?>